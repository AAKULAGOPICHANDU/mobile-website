import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.tasks.list.path, async (req, res) => {
    try {
      const date = req.query.date as string | undefined;
      const tasks = await storage.getTasks(date);
      res.json(tasks);
    } catch (err) {
      res.status(400).json({ message: "Invalid query" });
    }
  });

  app.get(api.tasks.get.path, async (req, res) => {
    const task = await storage.getTask(Number(req.params.id));
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.json(task);
  });

  app.post(api.tasks.create.path, async (req, res) => {
    try {
      const input = api.tasks.create.input.parse(req.body);
      const task = await storage.createTask(input);
      res.status(201).json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put(api.tasks.update.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const input = api.tasks.update.input.parse(req.body);
      
      const existing = await storage.getTask(id);
      if (!existing) {
        return res.status(404).json({ message: "Task not found" });
      }

      const updated = await storage.updateTask(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.tasks.delete.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const existing = await storage.getTask(id);
      if (!existing) {
        return res.status(404).json({ message: "Task not found" });
      }
      await storage.deleteTask(id);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Seed data function
  async function seedDatabase() {
    try {
      const existingTasks = await storage.getTasks();
      if (existingTasks.length === 0) {
        const today = new Date().toISOString().split('T')[0];
        await storage.createTask({
          title: "Morning Review",
          description: "Review daily goals and plan the day.",
          date: today,
          startTime: "09:00",
          endTime: "09:30",
          isCompleted: true,
          isAlarmSet: false
        });
        await storage.createTask({
          title: "Deep Work Session",
          description: "Focus on the most important project.",
          date: today,
          startTime: "10:00",
          endTime: "12:00",
          isCompleted: false,
          isAlarmSet: true
        });
        await storage.createTask({
          title: "Lunch Break",
          description: "Take a healthy lunch and rest.",
          date: today,
          startTime: "12:00",
          endTime: "13:00",
          isCompleted: false,
          isAlarmSet: true
        });
      }
    } catch (error) {
      console.error("Failed to seed database:", error);
    }
  }

  // Run seed function non-blocking
  seedDatabase();

  return httpServer;
}
