import { db } from "./db";
import { tasks, type CreateTaskRequest, type UpdateTaskRequest, type TaskResponse } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getTasks(date?: string): Promise<TaskResponse[]>;
  getTask(id: number): Promise<TaskResponse | undefined>;
  createTask(task: CreateTaskRequest): Promise<TaskResponse>;
  updateTask(id: number, updates: UpdateTaskRequest): Promise<TaskResponse>;
  deleteTask(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getTasks(date?: string): Promise<TaskResponse[]> {
    if (date) {
      return await db.select().from(tasks).where(eq(tasks.date, date));
    }
    return await db.select().from(tasks);
  }

  async getTask(id: number): Promise<TaskResponse | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(insertTask: CreateTaskRequest): Promise<TaskResponse> {
    const [task] = await db.insert(tasks).values(insertTask).returning();
    return task;
  }

  async updateTask(id: number, updates: UpdateTaskRequest): Promise<TaskResponse> {
    const [updated] = await db.update(tasks).set(updates).where(eq(tasks.id, id)).returning();
    return updated;
  }

  async deleteTask(id: number): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }
}

export const storage = new DatabaseStorage();
