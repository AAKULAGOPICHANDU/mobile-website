## Packages
canvas-confetti | For delightful task completion animations
@types/canvas-confetti | Types for the confetti library
date-fns | For date formatting, comparison, and manipulation
framer-motion | For beautiful timeline and card entry animations

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)", "sans-serif"],
  body: ["var(--font-sans)", "sans-serif"],
}
