import { useMemo } from "react";
import { format, isToday } from "date-fns";
import { Lightbulb, Sparkles, Coffee, Target } from "lucide-react";
import { type Task } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";

const formatTime12Hour = (timeStr: string) => {
  const [hours, minutes] = timeStr.split(':');
  const date = new Date();
  date.setHours(parseInt(hours, 10), parseInt(minutes, 10));
  return format(date, "h:mm a");
};

interface SmartSuggestionsProps {
  tasks: Task[] | undefined;
  selectedDate: string;
}

export function SmartSuggestions({ tasks, selectedDate }: SmartSuggestionsProps) {
  const suggestion = useMemo(() => {
    if (!tasks || tasks.length === 0) {
      return {
        icon: <Lightbulb className="w-6 h-6 text-yellow-400" />,
        title: "Blank Canvas",
        message: "Your day is entirely open. Schedule a few tasks to stay productive!",
        color: "from-yellow-500/10 to-amber-500/5",
        borderColor: "border-yellow-500/20"
      };
    }

    // Only give dynamic time-based suggestions for today
    if (!isToday(new Date(selectedDate))) {
      const completed = tasks.filter(t => t.isCompleted).length;
      if (completed === tasks.length) {
        return {
          icon: <Sparkles className="w-6 h-6 text-green-500" />,
          title: "Perfect Day",
          message: "You completed everything scheduled for this day. Amazing job!",
          color: "from-green-500/10 to-emerald-500/5",
          borderColor: "border-green-500/20"
        };
      }
      return {
        icon: <Target className="w-6 h-6 text-primary" />,
        title: "Plan Ahead",
        message: `You have ${tasks.length} tasks scheduled. A good plan is half the work done.`,
        color: "from-primary/10 to-accent/5",
        borderColor: "border-primary/20"
      };
    }

    const now = new Date();
    const currentTime = format(now, "HH:mm");

    // Sort tasks
    const sorted = [...tasks].sort((a, b) => a.startTime.localeCompare(b.startTime));
    
    // Find active task
    const activeTask = sorted.find(t => 
      !t.isCompleted && 
      currentTime >= t.startTime && 
      currentTime <= t.endTime
    );

    if (activeTask) {
      return {
        icon: <Target className="w-6 h-6 text-accent" />,
        title: "Focus Mode",
        message: `Stay focused on "${activeTask.title}" for the next while. You got this!`,
        color: "from-accent/15 to-primary/5",
        borderColor: "border-accent/30"
      };
    }

    // Find next task
    const nextTask = sorted.find(t => !t.isCompleted && currentTime < t.startTime);
    
    if (nextTask) {
      return {
        icon: <Coffee className="w-6 h-6 text-blue-400" />,
        title: "Take a Breather",
        message: `You have some free time before "${nextTask.title}" at ${formatTime12Hour(nextTask.startTime)}. Hydrate and stretch!`,
        color: "from-blue-500/10 to-cyan-500/5",
        borderColor: "border-blue-500/20"
      };
    }

    // All done for today
    const uncompleted = sorted.filter(t => !t.isCompleted).length;
    if (uncompleted === 0) {
      return {
        icon: <Sparkles className="w-6 h-6 text-green-500" />,
        title: "All Done!",
        message: "You've crushed your schedule for today. Time to relax and recharge.",
        color: "from-green-500/10 to-emerald-500/5",
        borderColor: "border-green-500/20"
      };
    }

    // Overdue tasks
    return {
      icon: <Lightbulb className="w-6 h-6 text-orange-400" />,
      title: "Wrap Up",
      message: `You have ${uncompleted} tasks left behind schedule. Try to wrap them up or move them to tomorrow.`,
      color: "from-orange-500/10 to-red-500/5",
      borderColor: "border-orange-500/20"
    };

  }, [tasks, selectedDate]);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={suggestion.title}
        initial={{ opacity: 0, y: 10, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -10, scale: 0.98 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className={`bg-gradient-to-r ${suggestion.color} border ${suggestion.borderColor} rounded-2xl p-5 shadow-sm`}
      >
        <div className="flex items-start gap-4">
          <div className="p-3 bg-card rounded-xl shadow-sm border border-border/50">
            {suggestion.icon}
          </div>
          <div className="flex-1">
            <h3 className="font-display font-semibold text-lg text-foreground mb-1">
              {suggestion.title}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              {suggestion.message}
            </p>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
