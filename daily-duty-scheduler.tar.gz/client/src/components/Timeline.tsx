import { useMemo } from "react";
import { type Task } from "@shared/schema";
import { TaskCard } from "./TaskCard";
import { AnimatePresence, motion } from "framer-motion";
import { CalendarX2 } from "lucide-react";

interface TimelineProps {
  tasks: Task[] | undefined;
  isLoading: boolean;
  onEditTask: (task: Task) => void;
}

export function Timeline({ tasks, isLoading, onEditTask }: TimelineProps) {
  const sortedTasks = useMemo(() => {
    if (!tasks) return [];
    return [...tasks].sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [tasks]);

  if (isLoading) {
    return (
      <div className="space-y-6 mt-8">
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex gap-4 animate-pulse">
            <div className="w-16 h-10 bg-secondary rounded-lg" />
            <div className="w-4 h-4 rounded-full bg-secondary mt-2" />
            <div className="flex-1 h-24 bg-secondary rounded-2xl" />
          </div>
        ))}
      </div>
    );
  }

  if (sortedTasks.length === 0) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center justify-center py-16 px-4 text-center border-2 border-dashed border-border rounded-3xl mt-8 bg-card/50"
      >
        <div className="bg-secondary p-4 rounded-full mb-4">
          <CalendarX2 className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="font-display text-xl font-bold text-foreground mb-2">No tasks scheduled</h3>
        <p className="text-muted-foreground max-w-sm">
          Your timeline is empty for this day. Click the button below to add your first task and start being productive!
        </p>
      </motion.div>
    );
  }

  return (
    <div className="relative mt-8 pb-12">
      <AnimatePresence>
        {sortedTasks.map((task, index) => (
          <TaskCard 
            key={task.id} 
            task={task} 
            index={index} 
            onEdit={onEditTask} 
          />
        ))}
      </AnimatePresence>
    </div>
  );
}
