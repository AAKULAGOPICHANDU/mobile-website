import { useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { z } from "zod";
import { api } from "@shared/routes";
import { useCreateTask, useUpdateTask } from "@/hooks/use-tasks";
import { type Task } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Clock, Calendar as CalendarIcon, Bell, Loader2 } from "lucide-react";

interface TaskFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  taskToEdit?: Task | null;
  selectedDate: string;
}

export function TaskFormDialog({ open, onOpenChange, taskToEdit, selectedDate }: TaskFormDialogProps) {
  const createMutation = useCreateTask();
  const updateMutation = useUpdateTask();

  const isEditing = !!taskToEdit;
  const isPending = createMutation.isPending || updateMutation.isPending;

  const form = useForm<z.infer<typeof api.tasks.create.input>>({
    resolver: zodResolver(api.tasks.create.input),
    defaultValues: {
      title: "",
      description: "",
      date: selectedDate,
      startTime: format(new Date(), "HH:mm"),
      endTime: format(new Date(Date.now() + 60 * 60 * 1000), "HH:mm"),
      isCompleted: false,
      isAlarmSet: true,
    },
  });

  // Format times to 12-hour for display
  const formatTime12Hour = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':');
    const date = new Date();
    date.setHours(parseInt(hours, 10), parseInt(minutes, 10));
    return format(date, "h:mm a");
  };

  const startTimeDisplay = useMemo(() => {
    const startTime = form.watch('startTime');
    return startTime ? formatTime12Hour(startTime) : '';
  }, [form.watch('startTime')]);

  const endTimeDisplay = useMemo(() => {
    const endTime = form.watch('endTime');
    return endTime ? formatTime12Hour(endTime) : '';
  }, [form.watch('endTime')]);

  // Reset form when opening/closing or changing task
  useEffect(() => {
    if (open) {
      if (taskToEdit) {
        form.reset({
          title: taskToEdit.title,
          description: taskToEdit.description || "",
          date: taskToEdit.date,
          startTime: taskToEdit.startTime,
          endTime: taskToEdit.endTime,
          isCompleted: taskToEdit.isCompleted,
          isAlarmSet: taskToEdit.isAlarmSet,
        });
      } else {
        form.reset({
          title: "",
          description: "",
          date: selectedDate,
          startTime: format(new Date(), "HH:mm"),
          endTime: format(new Date(Date.now() + 60 * 60 * 1000), "HH:mm"),
          isCompleted: false,
          isAlarmSet: true,
        });
      }
    }
  }, [open, taskToEdit, selectedDate, form]);

  const onSubmit = async (values: z.infer<typeof api.tasks.create.input>) => {
    try {
      if (isEditing && taskToEdit) {
        await updateMutation.mutateAsync({ id: taskToEdit.id, ...values });
      } else {
        await createMutation.mutateAsync(values);
      }
      onOpenChange(false);
    } catch (error) {
      console.error("Form submission error", error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] glass-effect border-none shadow-2xl rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">
            {isEditing ? "Edit Task" : "New Task"}
          </DialogTitle>
          <DialogDescription>
            {isEditing ? "Update your schedule details." : "Schedule something new for your day."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 mt-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-foreground/80">Task Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g. Deep work on project" 
                      className="bg-background/50 border-border/50 focus:ring-primary/20 transition-all rounded-xl"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-foreground/80 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Start
                    </FormLabel>
                    <FormControl>
                      <Input type="time" className="bg-background/50 border-border/50 rounded-xl" {...field} data-testid="input-start-time" />
                    </FormControl>
                    {startTimeDisplay && (
                      <FormDescription className="text-xs font-medium text-accent">
                        {startTimeDisplay}
                      </FormDescription>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-foreground/80 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> End
                    </FormLabel>
                    <FormControl>
                      <Input type="time" className="bg-background/50 border-border/50 rounded-xl" {...field} data-testid="input-end-time" />
                    </FormControl>
                    {endTimeDisplay && (
                      <FormDescription className="text-xs font-medium text-accent">
                        {endTimeDisplay}
                      </FormDescription>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-foreground/80 flex items-center gap-1">
                    <CalendarIcon className="w-3 h-3" /> Date
                  </FormLabel>
                  <FormControl>
                    <Input type="date" className="bg-background/50 border-border/50 rounded-xl" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-foreground/80">Description <span className="text-muted-foreground text-xs font-normal">(Optional)</span></FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any additional details or links..." 
                      className="resize-none bg-background/50 border-border/50 rounded-xl h-20"
                      {...field} 
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-secondary/40 p-4 rounded-xl space-y-4 border border-border/30">
              <FormField
                control={form.control}
                name="isAlarmSet"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between space-y-0">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base font-medium flex items-center gap-2">
                        <Bell className="w-4 h-4 text-accent" />
                        Remind Me
                      </FormLabel>
                      <FormDescription className="text-xs">
                        Get a notification when this starts
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end pt-4 gap-3">
              <Button 
                type="button" 
                variant="ghost" 
                onClick={() => onOpenChange(false)}
                className="rounded-xl hover:bg-secondary"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isPending}
                className="rounded-xl bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5"
              >
                {isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {isEditing ? "Save Changes" : "Create Task"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
