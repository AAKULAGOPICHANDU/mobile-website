import { useState } from "react";
import { format } from "date-fns";
import { type Task } from "@shared/schema";
import { motion } from "framer-motion";
import { 
  Bell, 
  MoreVertical, 
  Trash2, 
  Edit3, 
  Check,
  Clock
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useUpdateTask, useDeleteTask } from "@/hooks/use-tasks";
import confetti from "canvas-confetti";

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
  index: number;
}

export function TaskCard({ task, onEdit, index }: TaskCardProps) {
  const updateMutation = useUpdateTask();
  const deleteMutation = useDeleteTask();
  const [isDeleting, setIsDeleting] = useState(false);

  const handleToggleComplete = () => {
    const newValue = !task.isCompleted;
    updateMutation.mutate({ id: task.id, isCompleted: newValue });
    
    if (newValue) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#a855f7', '#ec4899']
      });
    }
  };

  const handleDelete = () => {
    setIsDeleting(true);
    deleteMutation.mutate(task.id);
  };

  // Convert "HH:mm" to 12-hour format for display
  const formatTime = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':');
    const date = new Date();
    date.setHours(parseInt(hours, 10), parseInt(minutes, 10));
    return format(date, "h:mm a");
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
      className="relative flex gap-4 w-full group"
    >
      {/* Timeline Column */}
      <div className="flex flex-col items-center min-w-[70px] pt-1">
        <span className="text-sm font-semibold text-foreground/80">
          {formatTime(task.startTime)}
        </span>
        <span className="text-xs text-muted-foreground mt-0.5">
          {formatTime(task.endTime)}
        </span>
      </div>

      {/* Timeline Node & Line */}
      <div className="relative flex flex-col items-center">
        <div className={`w-4 h-4 rounded-full border-2 z-10 bg-background transition-colors duration-300 ${
          task.isCompleted 
            ? 'border-green-500 bg-green-500' 
            : 'border-primary group-hover:border-accent'
        }`}>
          {task.isCompleted && <Check className="w-3 h-3 text-white absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />}
        </div>
        <div className="absolute top-4 bottom-[-16px] w-px bg-border group-last:bg-transparent" />
      </div>

      {/* Card Content */}
      <div className={`flex-1 mb-4 rounded-2xl border p-4 transition-all duration-300 ${
        task.isCompleted 
          ? 'bg-secondary/40 border-border/40 opacity-70' 
          : 'bg-card border-border/60 shadow-lg shadow-black/5 hover:shadow-xl hover:border-primary/30 hover:-translate-y-0.5'
      }`}>
        <div className="flex items-start justify-between gap-2">
          <div 
            className="flex-1 cursor-pointer"
            onClick={handleToggleComplete}
          >
            <h3 className={`font-display text-lg font-semibold transition-all ${
              task.isCompleted ? 'line-through text-muted-foreground' : 'text-foreground'
            }`}>
              {task.title}
            </h3>
            
            {task.description && (
              <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                {task.description}
              </p>
            )}
            
            <div className="flex items-center gap-3 mt-3">
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground bg-secondary/80 px-2 py-1 rounded-md">
                <Clock className="w-3 h-3" />
                {formatTime(task.startTime)} - {formatTime(task.endTime)}
              </div>
              
              {task.isAlarmSet && (
                <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-md ${
                  task.isCompleted ? 'bg-secondary text-muted-foreground' : 'bg-primary/10 text-primary'
                }`}>
                  <Bell className="w-3 h-3" />
                  Alarm On
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className={`h-8 w-8 rounded-full ${
                task.isCompleted ? 'text-green-500 hover:text-green-600 hover:bg-green-50' : 'text-muted-foreground hover:text-primary'
              }`}
              onClick={handleToggleComplete}
            >
              <Check className="w-5 h-5" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                  <MoreVertical className="w-4 h-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40 rounded-xl">
                <DropdownMenuItem onClick={() => onEdit(task)} className="cursor-pointer gap-2">
                  <Edit3 className="w-4 h-4" /> Edit
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={handleDelete} 
                  disabled={isDeleting}
                  className="cursor-pointer gap-2 text-destructive focus:text-destructive focus:bg-destructive/10"
                >
                  <Trash2 className="w-4 h-4" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
