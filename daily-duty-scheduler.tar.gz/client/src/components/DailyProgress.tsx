import { useMemo } from "react";
import { type Task } from "@shared/schema";
import { motion } from "framer-motion";
import { CheckCircle2, ListTodo } from "lucide-react";

interface DailyProgressProps {
  tasks: Task[] | undefined;
}

export function DailyProgress({ tasks }: DailyProgressProps) {
  const { total, completed, percentage } = useMemo(() => {
    if (!tasks || tasks.length === 0) return { total: 0, completed: 0, percentage: 0 };
    
    const total = tasks.length;
    const completed = tasks.filter(t => t.isCompleted).length;
    const percentage = Math.round((completed / total) * 100);
    
    return { total, completed, percentage };
  }, [tasks]);

  return (
    <div className="glass-effect rounded-2xl p-6 shadow-lg shadow-black/5">
      <div className="flex justify-between items-end mb-6">
        <div>
          <h2 className="font-display text-2xl font-bold text-foreground mb-1">Daily Progress</h2>
          <p className="text-sm text-muted-foreground">Keep up the great work!</p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-display font-bold text-gradient">{percentage}%</div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Completed</p>
        </div>
      </div>

      {/* Progress Bar Container */}
      <div className="relative h-4 bg-secondary rounded-full overflow-hidden mb-6 border border-border/50">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary to-accent rounded-full"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center gap-3 bg-secondary/50 p-3 rounded-xl border border-border/50">
          <div className="bg-primary/10 p-2 rounded-lg text-primary">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold font-display leading-none">{completed}</p>
            <p className="text-xs text-muted-foreground font-medium">Tasks Done</p>
          </div>
        </div>
        <div className="flex items-center gap-3 bg-secondary/50 p-3 rounded-xl border border-border/50">
          <div className="bg-muted p-2 rounded-lg text-muted-foreground">
            <ListTodo className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold font-display leading-none">{total - completed}</p>
            <p className="text-xs text-muted-foreground font-medium">Remaining</p>
          </div>
        </div>
      </div>
    </div>
  );
}
