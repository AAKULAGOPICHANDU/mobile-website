import { useEffect, useState, useRef } from "react";
import { format } from "date-fns";
import { useTasks } from "@/hooks/use-tasks";
import { useToast } from "@/hooks/use-toast";
import { BellRing } from "lucide-react";

export function AlarmManager() {
  const { data: tasks } = useTasks(format(new Date(), "yyyy-MM-dd"));
  const { toast } = useToast();
  // Keep track of tasks we've already alarmed for today
  const triggeredAlarms = useRef<Set<number>>(new Set());

  useEffect(() => {
    if (!tasks || tasks.length === 0) return;

    const checkAlarms = () => {
      const now = new Date();
      const currentTime = format(now, "HH:mm");

      tasks.forEach((task) => {
        if (
          task.isAlarmSet &&
          !task.isCompleted &&
          task.startTime === currentTime &&
          !triggeredAlarms.current.has(task.id)
        ) {
          toast({
            title: "⏰ Time for your next task!",
            description: (
              <div className="flex items-center gap-2 mt-2">
                <BellRing className="w-4 h-4 text-accent" />
                <span className="font-medium">{task.title}</span>
              </div>
            ),
            duration: 10000,
          });
          triggeredAlarms.current.add(task.id);
          
          // Optional: Attempt to play a sound if browser allows
          try {
            const audio = new Audio("https://actions.google.com/sounds/v1/alarms/digital_watch_alarm_long.ogg");
            audio.volume = 0.5;
            audio.play().catch(() => { /* Ignore auto-play restrictions */ });
          } catch (e) {
            // Ignore errors
          }
        }
      });
    };

    // Check immediately, then every 15 seconds
    checkAlarms();
    const intervalId = setInterval(checkAlarms, 15000);

    return () => clearInterval(intervalId);
  }, [tasks, toast]);

  return null; // This is a logic-only component
}
