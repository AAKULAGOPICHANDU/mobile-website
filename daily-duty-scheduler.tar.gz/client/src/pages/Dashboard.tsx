import { useState, useEffect } from "react";
import { format, addDays, subDays } from "date-fns";
import { useTasks } from "@/hooks/use-tasks";
import { type Task } from "@shared/schema";
import { Plus, ChevronLeft, ChevronRight, Calendar as CalendarIcon, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DailyProgress } from "@/components/DailyProgress";
import { SmartSuggestions } from "@/components/SmartSuggestions";
import { Timeline } from "@/components/Timeline";
import { TaskFormDialog } from "@/components/TaskFormDialog";

export default function Dashboard() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const dateStr = format(selectedDate, "yyyy-MM-dd");
  
  const { data: tasks, isLoading } = useTasks(dateStr);
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  
  // Theme handling (simplistic approach for demo, usually use next-themes)
  const [isDark, setIsDark] = useState(false);
  useEffect(() => {
    if (isDark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDark]);

  const handleEditTask = (task: Task) => {
    setTaskToEdit(task);
    setIsFormOpen(true);
  };

  const handleOpenNewTask = () => {
    setTaskToEdit(null);
    setIsFormOpen(true);
  };

  const isToday = format(new Date(), "yyyy-MM-dd") === dateStr;

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300 pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 glass-effect border-b border-border/50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-tr from-primary to-accent w-8 h-8 rounded-lg flex items-center justify-center shadow-lg shadow-primary/20">
              <span className="text-white font-display font-bold text-lg leading-none">D</span>
            </div>
            <h1 className="font-display font-bold text-xl tracking-tight hidden sm:block">Daily Duty</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full"
              onClick={() => setIsDark(!isDark)}
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 pt-8 space-y-8">
        {/* Date Navigator */}
        <div className="flex items-center justify-between glass-effect rounded-2xl p-2 shadow-sm border border-border/50">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-xl hover:bg-secondary"
            onClick={() => setSelectedDate(subDays(selectedDate, 1))}
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          
          <div className="flex items-center gap-2 px-4 cursor-pointer" onClick={() => setSelectedDate(new Date())}>
            <CalendarIcon className="w-4 h-4 text-primary" />
            <span className="font-display font-semibold text-lg">
              {isToday ? "Today" : format(selectedDate, "EEE, MMM d")}
            </span>
          </div>

          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-xl hover:bg-secondary"
            onClick={() => setSelectedDate(addDays(selectedDate, 1))}
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>

        {/* Dashboard Widgets */}
        <div className="space-y-6">
          <DailyProgress tasks={tasks} />
          <SmartSuggestions tasks={tasks} selectedDate={dateStr} />
        </div>

        {/* Timeline Section */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-display text-2xl font-bold">Timeline</h2>
            <div className="text-sm font-medium text-muted-foreground bg-secondary/50 px-3 py-1 rounded-full">
              {tasks?.length || 0} tasks
            </div>
          </div>
          
          <Timeline 
            tasks={tasks} 
            isLoading={isLoading} 
            onEditTask={handleEditTask} 
          />
        </div>
      </main>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 sm:bottom-10 sm:right-10 z-50">
        <Button 
          size="icon" 
          className="w-14 h-14 rounded-full bg-gradient-to-r from-primary to-accent shadow-xl shadow-primary/30 hover:shadow-2xl hover:scale-105 transition-all duration-300"
          onClick={handleOpenNewTask}
        >
          <Plus className="w-6 h-6 text-white" />
        </Button>
      </div>

      {/* Task Form Modal */}
      <TaskFormDialog 
        open={isFormOpen} 
        onOpenChange={setIsFormOpen} 
        taskToEdit={taskToEdit}
        selectedDate={dateStr}
      />
    </div>
  );
}
